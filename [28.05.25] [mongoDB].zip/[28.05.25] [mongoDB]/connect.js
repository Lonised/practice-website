const { MongoClient } = require('mongodb');
const uri = "mongodb+srv://daniilshterkel05:2680@practice.c1rrymd.mongodb.net/?retryWrites=true&w=majority&appName=practice";
const client = new MongoClient(uri);

async function connectToDB() {
    try {
        await client.connect();
        console.log("Успешно подключено к MongoDB");
        return client.db("test");
    } catch (err) {
        console.error("Ошибка подключения", err);
        throw err;
    }
}

module.exports = { connectToDB, client };




  
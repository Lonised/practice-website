async function addUser(db, user) { 
    try {
      const collection = db.collection("users");
      const result = await collection.insertOne(user);
      console.log("Пользователь добавлен:", result.insertedId);
    } catch (err) {
      console.error("Ошибка вставки:", err);
    }
  }
  
  module.exports = addUser;
  
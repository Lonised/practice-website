const readline = require('readline');
const { connectToDB, client } = require('./connect');
const addUser = require('./addUser');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

async function main() {
  rl.question("Введите имя: ", async (name) => {
    rl.question("Введите возраст: ", async (age) => {
      const db = await connectToDB();

      await addUser(db, { name, age: parseInt(age), createdAt: new Date() });

      await client.close();
      rl.close();
    });
  });
}

main();
